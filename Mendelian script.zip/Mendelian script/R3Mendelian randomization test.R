
rm(list=ls())
# 判断是否已经安装了“pacman”包，如果没有就安装它
if(!require("pacman")) install.packages("pacman",update = F,ask = F)
# 设置Bioconductor镜像地址为中国科技大学的镜像
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") #https://mirrors.pku.edu.cn/CRAN/
# 加载“pacman”包，用于方便加载其他的R包
# 安装并加载pacman包,用于批量安装加载包
if(!require("pacman")) install.packages("pacman",update = F,ask = F)

# 设置镜像加速bioconductor包安装
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") 

# 加载pacman包
library("pacman")

# 批量安装加载需要的包
p_load(data.table,ggplot2,TwoSampleMR) 


#install.packages("devtools")
#devtools::install_github("MRCIEU/TwoSampleMR")
outcomefile = "ieu-b-42"
or_pfilter = 0.05

MRresult_data=fread("allMRresult.txt",header = T,sep = "\t")
immucell_ID=as.vector(MRresult_data$id)
immucell_ID=immucell_ID[1:4]
# 载入数据
# immucell_ID为免疫细胞ID

# 提取曝露因素SNP
# p1为LD阈值,clump为True表示进行LD泯灭,p2为p值阈值,r2为相关系数阈值,kb为窗口大小
for (i in immucell_ID) {
  expo_data <- extract_instruments(outcome = i, p1 = 1e-5,
                                   clump = T, p2 = 1e-5, 
                                   r2 = 0.001, kb = 10000)
  
  # 提取结果因变量数据  
  outc_data <- extract_outcome_data(snps = expo_data$SNP,
                                    outcomes = outcomefile)
  
  # 调和曝露因素和结果数据
  harm_data <- harmonise_data(exposure_dat = expo_data, 
                              outcome_dat = outc_data,
                              action = 2)
  
  # 进行MR分析
  mr_result <- mr(harm_data)
  
  # 生成优比值  
  result_or <- generate_odds_ratios(mr_result)
  
  # 创建输出目录
  dir.create(i)
  filename = i
  
  # 输出结果
  write.table(harm_data, file = paste0(filename,"/harmonise.txt"),
              row.names = F, sep = "\t", quote = F)
  
  write.table(result_or[,5:ncol(result_or)], 
              file = paste0(filename,"/OR.txt"),
              row.names = F, sep = "\t", quote = F)
  
  # 保存 odds ratio 数据，并使用 filename 作为前缀
  write.table(result_or[, 5:ncol(result_or)], 
              file = paste0(filename, "_OR.txt"), 
              row.names = FALSE, sep = "\t", quote = FALSE)
  
  
  # 绘制散点图             
  p1 <- mr_scatter_plot(mr_result, harm_data)
  ggsave(p1[[1]], file=paste0(filename,"/scatter.pdf"), 
         width=8, height=8)
  
  # 进行多重比较校正
  pleiotropy <- mr_pleiotropy_test(harm_data)
  write.table(pleiotropy, file = paste0(filename,"/pleiotropy.txt"),
              sep = "\t", quote = F)
  
  # 进行异质性检验
  heterogeneity <- mr_heterogeneity(harm_data)
  write.table(heterogeneity, file = paste0(filename,"/heterogeneity.txt"),
              sep = "\t", quote = F)
  
  # MR-PRESSO
  presso <- run_mr_presso(harm_data, NbDistribution = 1000)
  capture.output(presso, file = paste0(filename,"/presso.txt"))
  
  # 单个SNP分析 
  singlesnp_res <- mr_singlesnp(harm_data)
  singlesnpOR <- generate_odds_ratios(singlesnp_res)
  write.table(singlesnpOR, file=paste0(filename,"/singlesnpOR.txt"),
              row.names = F, sep = "\t", quote = F)
  
  # 森林图
  p2 <- mr_forest_plot(singlesnp_res)
  ggsave(p2[[1]], file=paste0(filename,"/forest.pdf"), width=8, height=8)
  
  # Leave-one-out分析
  sen_res <- mr_leaveoneout(harm_data)
  p3 <- mr_leaveoneout_plot(sen_res)
  ggsave(p3[[1]], file=paste0(filename,"/sensitivity-analysis.pdf"), 
         width=8, height=8)
  
  # Funnel plot检验，如果不存在publication bias,那么数据点应该对称分布在两侧,呈漏斗形分布。
  res_single <- mr_singlesnp(harm_data)
  p4 <- mr_funnel_plot(singlesnp_res)
  ggsave(p4[[1]], file=paste0(filename,"/funnelplot.pdf"), width=8, height=8)
  
}
