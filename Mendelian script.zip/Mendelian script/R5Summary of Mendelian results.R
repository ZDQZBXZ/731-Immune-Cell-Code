
rm(list=ls())
# 判断是否已经安装了“pacman”包，如果没有就安装它
if(!require("pacman")) install.packages("pacman",update = F,ask = F)
# 设置Bioconductor镜像地址为中国科技大学的镜像
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") #https://mirrors.pku.edu.cn/CRAN/
# 加载“pacman”包，用于方便加载其他的R包
# 安装并加载pacman包,用于批量安装加载包
if(!require("pacman")) install.packages("pacman",update = F,ask = F)

# 设置镜像加速bioconductor包安装
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") 

# 加载pacman包
library("pacman")

# 批量安装加载需要的包
p_load(data.table,dplyr) 

# 创建一个空列表来存储所有数据框
df_list <- list()

# 遍历所有TXT文件
files <- list.files(pattern="*_OR.txt")
for(f in files){
  # 读取每个TXT文件为数据框
  df <- fread(f, header=TRUE,sep = "\t",quote = F,)
  df$id <- f
  # 使用 gsub 去掉 "_OR.txt"
  df$id <- gsub("_OR.txt", "", df$id)
  # 添加到列表中
  df_list <- c(df_list, list(df))
}

# 通过列名合并多个数据框
combined_df <- Reduce(function(x,y) rbind(x,y), df_list)

write.table(combined_df,"allOR.txt",sep = "\t",quote = F,row.names = F)

ivw_data <- combined_df %>% 
           filter(method=="Inverse variance weighted")

write.table(combined_df,"ivw_allOR.txt",sep = "\t",quote = F,row.names = F)
