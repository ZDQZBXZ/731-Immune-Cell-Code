
rm(list=ls())
# 判断是否已经安装了“pacman”包，如果没有就安装它
if(!require("pacman")) install.packages("pacman",update = F,ask = F)
# 设置Bioconductor镜像地址为中国科技大学的镜像
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") #https://mirrors.pku.edu.cn/CRAN/
# 加载“pacman”包，用于方便加载其他的R包
# 安装并加载pacman包,用于批量安装加载包
if(!require("pacman")) install.packages("pacman",update = F,ask = F)

# 设置镜像加速bioconductor包安装
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") 

# 加载pacman包
library("pacman")

# 批量安装加载需要的包
p_load(data.table,purrr) 

# 如果没有 devtools 包,则安装 devtools 包
if (!require("devtools")) {
  install.packages("devtools")
} else {}

# 如果没有 data.table 包,则安装 data.table 包  
if (!require("data.table")) {
  install.packages("data.table")
} else {}

# 如果没有 TwoSampleMR 包,则从 GitHub 安装 TwoSampleMR 包
if (!require("TwoSampleMR")) {
  devtools::install_github("MRCIEU/TwoSampleMR") 
} else {}


# 如果没有 TwoSampleMR 包,则从 GitHub 安装 TwoSampleMR 包
if (!require("MRInstruments")) {
  devtools::install_github("MRCIEU/MRInstruments") 
} else {}

# 设置仪器变量文件
expofile = "immID.txt"

# 设置结果变量文件
outcomefile = "ieu-b-42"

# 设置显著性阈值 
or_pfilter = 0.05

# 读取仪器变量数据
immucell_data = fread(expofile,header = T,sep = "\t")  

# 提取id为向量
immucell_ID = as.vector(immucell_data$id)

immucell_ID

# 取id子集
#immucell_ID = immucell_ID[1:3]   

# 使用 map 循环处理每个id
Biofsci <- map_df(immucell_ID, function(i) {
  tryCatch({
    # 提取仪器变量
    expo_data <- extract_instruments(outcome = i,
                                     p1 = 1e-5,
                                     clump = TRUE,
                                     p2 = 1e-5,
                                     r2 = 0.001,
                                     kb = 10000)
    
    # 提取结果变量                                
    outc_data <- extract_outcome_data(snps = expo_data$SNP,
                                      outcomes = outcomefile)  
    
    # 匹配变量                                  
    harm_data <- harmonise_data(exposure_dat = expo_data,
                                outcome_dat = outc_data, action = 2)
    
    # MR分析
    mr_result <- mr(harm_data)
    
    # 生成OR值
    MRresult_or = generate_odds_ratios(mr_result)
    
    # 筛选显著结果
    if (MRresult_or$pval[3] < or_pfilter) {
      # 返回一个数据框，包含id和pvalue
      return(data.frame(id = i, pvalue = MRresult_or$pval[3]))
    } else {
      # 如果不显著，返回空数据框
      return(data.frame())
    }
  }, error = function(e) {
    # 处理可能的错误
    return(data.frame())
  })
})

# 输出结果表
write.table(Biofsci, "MRresult1.txt", sep = "\t", quote = FALSE, row.names = FALSE)