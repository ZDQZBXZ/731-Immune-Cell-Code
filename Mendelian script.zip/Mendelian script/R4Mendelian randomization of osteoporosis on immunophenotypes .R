rm(list=ls())
# 判断是否已经安装了“pacman”包，如果没有就安装它
if(!require("pacman")) install.packages("pacman",update = F,ask = F)
# 设置Bioconductor镜像地址为中国科技大学的镜像
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") #https://mirrors.pku.edu.cn/CRAN/
# 加载“pacman”包，用于方便加载其他的R包
# 安装并加载pacman包,用于批量安装加载包
if(!require("pacman")) install.packages("pacman",update = F,ask = F)

# 设置镜像加速bioconductor包安装
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/") 

# 加载pacman包
library("pacman")

# 批量安装加载需要的包
p_load(data.table,ggplot2,TwoSampleMR,purrr) 

#install packages
#install.packages("devtools")
#devtools::install_github("MRCIEU/TwoSampleMR")


# 定义文件名和参数
MRresultfile = "allMRresult.txt"  # MR结果文件
expofile = "ieu-b-42"  # 外部暴露数据文件
or_pfilter = 1  # 滤除 odds ratio 的阈值

# 读取 MR 结果数据
MRresult_data = read.table(MRresultfile, header = TRUE, sep = "\t")
immucell_ID = as.vector(MRresult_data$id)  # 提取id列的数据
immucell_ID
immucell_ID=immucell_ID[2:13]
# 使用 map 循环遍历 immucell_ID 中的每个元素
results <- map(immucell_ID, function(i) {
  # 提取外部暴露数据
  expo_data <- extract_instruments(outcome = expofile, p1 = 5e-8, clump = TRUE, p2 = 5e-8, r2 = 0.001, kb = 10000)
  
  # 提取结果数据
  outc_data <- extract_outcome_data(snps = expo_data$SNP, outcomes = i)
  
  # 数据协调处理
  harm_data <- harmonise_data(exposure_dat = expo_data, outcome_dat = outc_data, action = 2)
  
  # 进行 Mendelian Randomization 分析
  mr_result <- mr(harm_data)
  result_or = generate_odds_ratios(mr_result)
  
  # 如果结果的第三个p值小于设定的阈值，执行以下操作
  if (result_or$pval[3] < or_pfilter) {
    dir.create(i)  # 创建一个目录
    filename = i
    
    # 保存协调处理数据
    write.table(harm_data, file = paste0(filename, "/harmonise.txt"), row.names = FALSE, sep = "\t", quote = FALSE)
    
    # 保存 odds ratio 数据
    write.table(result_or[, 5:ncol(result_or)], 
                file = paste0(filename, "/ORReverse.txt"), 
                row.names = FALSE, sep = "\t", quote = FALSE)
    
    # 保存 odds ratio 数据，并使用 filename 作为前缀
    write.table(result_or[, 5:ncol(result_or)], 
                file = paste0(filename, "_ORReverse.txt"), 
                row.names = FALSE, sep = "\t", quote = FALSE)
    
    
    # 进行 MR 的共线性检验
    pleiotropy = mr_pleiotropy_test(harm_data)
    write.table(pleiotropy, file = paste0(filename, "/pleiotropy.txt"), sep = "\t", quote = FALSE)
    
    # 进行 MR 的异质性检验
    heterogeneity = mr_heterogeneity(harm_data)
    write.table(heterogeneity, file = paste0(filename, "/heterogeneity.txt"), sep = "\t", quote = FALSE)
    
    # 运行 MR PRESSO 分析
    presso = run_mr_presso(harm_data, NbDistribution = 1000)
    capture.output(presso, file = paste0(filename, "/presso.txt"))
    
    # 生成 MR scatter plot 并保存
    p1 = mr_scatter_plot(mr_result, harm_data)
    ggsave(p1[[1]], file = paste0(filename, "/scatter.pdf"), width = 8, height = 8)
    
    # 进行 MR 单一SNP分析
    singlesnp_res = mr_singlesnp(harm_data)
    singlesnpOR = generate_odds_ratios(singlesnp_res)
    
    # 保存单一SNP的 odds ratio 数据
    write.table(singlesnpOR, file = paste0(filename, "/singlesnpOR.txt"), row.names = FALSE, sep = "\t", quote = FALSE)
    
    # 生成 MR forest plot 并保存
    p2 = mr_forest_plot(singlesnp_res)
    ggsave(p2[[1]], file = paste0(filename, "/forest.pdf"), width = 8, height = 8)
    
    # 进行 MR leave-one-out 分析
    sen_res = mr_leaveoneout(harm_data)
    
    # 生成 MR sensitivity-analysis 图并保存
    p3 = mr_leaveoneout_plot(sen_res)
    ggsave(p3[[1]], file = paste0(filename, "/sensitivity-analysis.pdf"), width = 8, height = 8)
    
    # 重新进行 MR 单一SNP分析
    res_single = mr_singlesnp(harm_data)
    
    # 生成 MR funnel plot 并保存
    p4 = mr_funnel_plot(singlesnp_res)
    ggsave(p4[[1]], file = paste0(filename, "/funnelplot.pdf"), width = 8, height = 8)
  }
})
